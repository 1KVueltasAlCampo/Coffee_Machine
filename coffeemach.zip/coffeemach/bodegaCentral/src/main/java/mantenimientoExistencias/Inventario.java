package mantenimientoExistencias;

public interface Inventario {
    public void abastecerSuministros();

    public void abastecerMonedas();

    public void abastecerIngredientes();

}
