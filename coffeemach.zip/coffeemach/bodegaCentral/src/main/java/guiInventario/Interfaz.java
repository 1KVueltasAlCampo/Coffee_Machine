package guiInventario;

import bodega.Bodega;
import mantenimientoExistencias.Inventario;

public class Interfaz {

    private Inventario inventario;
    private Bodega bodega;
}
