public class BodegaCentral {

    public static void main(String[] args) {
        System.out.println("Sin Implementación");
    }
}
