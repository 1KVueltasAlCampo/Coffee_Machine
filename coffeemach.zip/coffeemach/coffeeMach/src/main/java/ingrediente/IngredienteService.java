package ingrediente;

public interface IngredienteService {

    public void darExistencia();
}
