package suministro;

public class SuministroServiceImp implements SuministroService {

    @Override
    public boolean verificatExistenciaSuministro(String sumId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'verificatExistenciaSuministro'");
    }

    @Override
    public String[] darInsumos() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'darInsumos'");
    }

    @Override
    public void dispensarSuministro(String sumId) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'dispensarSuministro'");
    }

}
