package McControlador;

public class VentaService {

}
